<?php
require __DIR__.'/lib/Weixin/Autoloader.php';
Weixin\Autoloader::register();
