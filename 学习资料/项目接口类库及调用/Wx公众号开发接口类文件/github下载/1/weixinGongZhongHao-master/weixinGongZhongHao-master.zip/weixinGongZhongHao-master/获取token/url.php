<?php
/**
 * Created by PhpStorm.
 * User: lan
 * Date: 17/1/4
 * Time: 下午4:39
 */
echo urlencode('http://2.weixinbuild.applinzi.com/code.php');